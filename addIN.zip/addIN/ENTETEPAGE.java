package addIN;

import java.awt.BorderLayout;
import java.awt.Desktop;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
public class ENTETEPAGE extends JPanel implements ActionListener {
	
	/**
	 * @author adrien
	 * 
	 */
	@Deprecated
	private static final long serialVersionUID = 1L;
	
	
	protected JButton helpIcon,check_NB;
	protected JComboBox<Integer>nbCouleurs;
	public static int choix_nb;
	protected Integer[]list=new Integer[]{1,2,3,4,5,6,7,8,9,10};
	protected File helpPage=new File("src/addIn/help.html");
	protected Desktop desktop = Desktop.getDesktop();
	
	public ENTETEPAGE() {
		setLayout(new BorderLayout());
		helpIcon=new JButton("HELP PAGE");
		check_NB=new JButton("OK");
		nbCouleurs=new JComboBox<>(list);
		nbCouleurs.setName("nombre de couleur a chosir");
		add(check_NB,BorderLayout.WEST);
		add(helpIcon,BorderLayout.EAST);
		add(nbCouleurs,BorderLayout.CENTER);
		setVisible(true);
		//action listener
		check_NB.addActionListener(this);
		helpIcon.addActionListener(this);
		nbCouleurs.addActionListener(this);
		check_NB.setEnabled(false);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource().equals(check_NB)){
			choix_nb=nbCouleurs.getSelectedIndex()+1;
			System.err.println(choix_nb);
		}else if(e.getSource().equals(helpIcon)){
			try {
				desktop.open(helpPage);
			} catch (IOException e1) {
			
				e1.printStackTrace();
			}
		}else if(e.getSource().equals(nbCouleurs)){
			check_NB.setEnabled(true);
		}
		
	}
	public static void main(String[] args) {
		JFrame test=new JFrame();
		test.getContentPane().add(new ENTETEPAGE());
		test.pack();
		test.setVisible(true);
	}
}
