package brisseta;

public enum Etat {
 ABS("ABS"),EXC("EXC"),NONE("-"),VAl("");
	
	
 	Etat(String valeur){
	 
 }
}
