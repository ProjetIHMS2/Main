package brisseta;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.text.ParseException;

public class Note {
	protected double valeur;
	protected Etat etat;

	public Note() {
		this.etat=Etat.NONE;

	}
	public Note(double valeur){
		if(valeur<20.0 && valeur>0.0){
			this.valeur=valeur;
			this.etat=Etat.VAl;
		}else{
			this.valeur=0.0;
			this.etat=Etat.NONE;
		}
	}
	public Note(Etat etat){
		if(etat.equals(Etat.VAl)){
			this.etat=Etat.NONE;
		}else if(etat.equals(Etat.ABS)){
			this.valeur=0.0;
		}
		this.etat=etat;
	}
	public Note(String initial) throws ParseException{
		if(initial.equals("NONE")){
			this.etat=Etat.NONE;
		}else if(initial.equals("ABS")){
			this.valeur=0.0;
			this.etat=Etat.ABS;
		}else if(initial.equals("EXC")){
			this.etat=Etat.EXC;
		}else if(initial.equals(null)){
			new NullPointerException("Chaine vide");
		}
		new Exception("aucun des Etats reconnus");
		double tmp=Double.parseDouble(initial);

	}
	public Etat getEtat() {
		return etat;
	}
	public double getValeur() {
		return valeur;
	}
	public boolean same(Note note){

		if(this.getEtat().equals(Etat.VAl)){
			if(this.getValeur() == note.getValeur()){
				return true;
			}
			return false;

		}else if(this.getEtat().equals(note.getEtat()) && (this.getEtat() != Etat.VAl)){
			return true;
		}

		return false;
	}
	static void	extraction(Note[][] notes,String chemin){
		File fichier=new File(chemin+".csv");
		final char separator=',';
		try {
			PrintWriter w=new PrintWriter(fichier);
			for (int i = 0; i < notes.length; i++) {
				for (int j = 0; j < notes.length; j++) {
					if(notes[i][j].getEtat().equals(Etat.VAl)){
						w.print(notes[i][j].getValeur()+separator);
					}else if(!notes[i][j].getEtat().equals(Etat.VAl)){
						w.print(notes[i][j].getEtat().toString()+separator);
					}
				}
			}
			w.close();

		} catch (FileNotFoundException e) {

			e.printStackTrace();
		}
	}
	public static void extractionMoyenne(Note[][] notes,String chemin){
		File fichier=new File(chemin+".csv");
		double somme=0.0;
		final char separator=',';
		try {
			PrintWriter w=new PrintWriter(fichier);
			for (int i = 0; i < notes.length; i++) {
				for (int j = 0; j < notes.length; j++) {
					if(notes[i][j].getEtat().equals(Etat.VAl)){
						w.print(notes[i][j].getValeur()+separator);
						somme+=notes[i][j].getValeur();
					}else if(!notes[i][j].getEtat().equals(Etat.VAl)){
						w.print(notes[i][j].getEtat().toString()+separator);
					}
				}
			}
			w.print("taille"+notes.length+separator);
			w.print("Moyenne = "+somme/notes.length);
			w.close();

		} catch (FileNotFoundException e) {

			e.printStackTrace();
		}
	}
	@Override
	public String toString() {
		return "Note : "+this.valeur+"Etat : "+this.etat;
	}
}
