package brisseta;

import static org.junit.Assert.*;

import org.junit.Test;

public class NoteConstructorTest {

	@Test
	public void note_without_info_should_give_NONE(){
		Note test=new Note();
		assertTrue(test.getEtat().equals(Etat.NONE));
		
	}
	@Test
	public void note_with_info(){
		Note test=new Note(-2.1);
		assertTrue(test.getEtat().equals(Etat.NONE));
	}
	@Test
	public void etat_differOf(){
		Note test2=new  Note(Etat.ABS);
		assertFalse(test2.getEtat().equals(Etat.NONE));
	}
	@Test
	public void test_with_info(){
		Note test3=new Note(21.0);
		assertTrue(test3.getEtat().equals(Etat.NONE));
	}
	@Test
	public void etat_is_etat_choisi(){
		Note test=new Note(Etat.EXC);
		
	}
	@Test
	public void NoteSameTest_value1(){
		Note tmp=new Note(12.5555);
		Note tmp2=new Note(11.5555);
		System.err.println(tmp.getEtat());
		System.err.println(tmp2.getEtat());
		assertFalse(tmp.same(tmp2));
		
	}
	@Test
	public void ToString_test_sans_param(){
		Note tmp=new Note();
		System.out.println(tmp.toString());
	}
	@Test
	public void ToString_test_avec_param(){
		Note tmp=new Note(12.5);
		System.out.println(tmp.toString());
	}
	@Test
	public void ToString_test_param2(){
		Note tmp=new Note(Etat.ABS);
		System.out.println(tmp.toString());
	}
	
}
