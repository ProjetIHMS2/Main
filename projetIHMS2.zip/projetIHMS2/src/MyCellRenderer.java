

import java.awt.Component;
import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.ListCellRenderer;

class MyCellRenderer extends JLabel implements ListCellRenderer<Object> {
	final static ImageIcon fichier = new ImageIcon("file.png");
	final static ImageIcon repertoire = new ImageIcon("folder.png");

    // This is the only method defined by ListCellRenderer.
    // We just reconfigure the JLabel each time we’re called.

    public Component getListCellRendererComponent(
      JList<?> list,           // the list
      Object value,            // value to display
      int index,               // cell index
      boolean isSelected,      // is the cell selected
      boolean cellHasFocus)    // does the cell have focus
    {
        String s = value.toString();
        setText(s);
        File tmp=new File("/usr/include/"+s);
        setIcon((tmp.isDirectory()) ? repertoire : fichier);
        if (isSelected) {
            setBackground(list.getSelectionBackground());
            setForeground(list.getSelectionForeground());
        } else {
            setBackground(list.getBackground());
            setForeground(list.getForeground());
        }
        setEnabled(list.isEnabled());
        setFont(list.getFont());
        setOpaque(true);
        return this;
    }
}
