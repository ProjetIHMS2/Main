package Menu_interfacePrincipales;

import javax.swing.ImageIcon;
import javax.swing.JFrame;

public class Main {
	 public static JFrame frame;
	 
	public static void main(String[] args) {
		
		MenuPrincipal menu=new MenuPrincipal();
		ImageIcon background=new ImageIcon("images/bg.png");

	}

}
