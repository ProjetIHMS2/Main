package Menu_interfacePrincipales;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class Couleur extends JPanel implements ChangeListener, MouseListener{
	protected int r,g,b;
	protected JSlider slider_r,slider_g,slider_b;
	protected Color c;
	protected final int MIN=0,MAX=255;
	JLabel label;

  public Couleur() {

    super(true);
    this.r=MAX/2;
    this.g=MAX/2;
    this.b=MAX/2;
    this.setLayout(new BorderLayout());
     slider_r = new JSlider(JSlider.HORIZONTAL, MIN, MAX, (int)MAX/2);
     slider_g = new JSlider(JSlider.HORIZONTAL, MIN, MAX, (int)MAX/2);
     slider_b = new JSlider(JSlider.HORIZONTAL, MIN, MAX, (int)MAX/2);
     //setter des ticks
     	//slider_r
    slider_r.setMinorTickSpacing(2);
    slider_r.setMajorTickSpacing(50);
    	//slider_g
    slider_g.setMinorTickSpacing(2);
    slider_g.setMajorTickSpacing(50);
    	//slider_b
    slider_b.setMinorTickSpacing(2);
    slider_b.setMajorTickSpacing(50);
    	//painting
    slider_r.setPaintTicks(true);
    slider_r.setPaintLabels(true);
    slider_g.setPaintTicks(true);
    slider_g.setPaintLabels(true);
    slider_b.setPaintTicks(true);
    slider_b.setPaintLabels(true);
    slider_r.addChangeListener(this);
    slider_g.addChangeListener(this);
    slider_b.addChangeListener(this);
    


    add(slider_r, BorderLayout.WEST);
    add(slider_g, BorderLayout.CENTER);
    add(slider_b, BorderLayout.EAST);
    
    //Jlabel
    
    label=new JLabel("Votre couleur");
    label.setBackground(Color.white);
    add(label, BorderLayout.NORTH);
  }

@Override
public void stateChanged(ChangeEvent e) {
	JSlider source = (JSlider)e.getSource();
	if(source.equals(slider_r)){
		this.r=slider_r.getValue();
		System.out.println("red:"+this.r);
	}else if(source.equals(slider_g)){
		this.g=slider_g.getValue();
		System.out.println("green:"+this.g);
	}else{
		this.b=slider_b.getValue();
		System.out.println("bleu:"+this.b);
	}
	label.setText("r="+this.r+"g="+this.g+"b="+this.b);
	label.setBackground(new Color(this.r, this.g, this.b));
	label.repaint();
}

@Override
public void mouseClicked(MouseEvent e) {
	// TODO Auto-generated method stub
	
}

@Override
public void mouseEntered(MouseEvent e) {
	// TODO Auto-generated method stub
	
}

@Override
public void mouseExited(MouseEvent e) {
	// TODO Auto-generated method stub
	
}

@Override
public void mousePressed(MouseEvent e) {
	// TODO Auto-generated method stub
	
}

@Override
public void mouseReleased(MouseEvent e) {
	// TODO Auto-generated method stub
	
}


}
