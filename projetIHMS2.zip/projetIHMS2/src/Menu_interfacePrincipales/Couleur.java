package Menu_interfacePrincipales;

import java.awt.Color;

public class Couleur extends Color{

	protected int r;
	protected int g;
	protected int b;
	
	
	public Couleur(int r, int g, int b) {
		super(r, g, b);
		// TODO  une methode permettant de nommer ce couleur 
	}

	
}
