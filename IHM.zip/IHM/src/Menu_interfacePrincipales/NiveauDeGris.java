package Menu_interfacePrincipales;

public class NiveauDeGris extends Couleur{
	protected int r,g,b;
	  
	
	public NiveauDeGris(Couleur c) {
		this.r=c.getR();
		this.g=c.getG();
		this.b=c.getB();
	}
}
