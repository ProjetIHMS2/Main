package Menu_interfacePrincipales;

public class NiveauDeGris extends CouleurRGB{
	protected int r,g,b;
	  
	
	public NiveauDeGris(CouleurRGB c) {
		this.r=c.getR();
		this.g=c.getG();
		this.b=c.getB();
	}
}
