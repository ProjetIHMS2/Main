package Menu_interfacePrincipales;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JPanel;
import javax.swing.JTextField;

public class PreVisualisation extends JPanel {
	
	protected JTextField cadre;
	protected JPanel zone;
	protected Couleur c;
	
	/**
	 * @author brisseta 
	 */@Deprecated 
	private static final long serialVersionUID = 1L;
	 
		public PreVisualisation() {
			c=new Couleur();
			this.cadre=new JTextField();
			this.cadre.setPreferredSize(new Dimension(20,20));
			this.zone=new JPanel();
			zone.add(cadre,BorderLayout.CENTER);
			zone.setVisible(true);
			
		}
		public void dessinerPrevisu(){
			cadre.setBackground(new Color(c.r, c.g, c.b));
		}
		
}
