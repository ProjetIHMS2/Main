package Menu_interfacePrincipales;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

import addIn.ENTETEPAGE;
 t
public class Main {
	 public static JFrame premierefenetre;
	 
	public static void main(String[] args) {
		boolean end=false;
		PreVisualisation pv;
		//MenuPrincipal menu=new MenuPrincipal();
		ImageIcon background=new ImageIcon("images/bg.png");
		CouleurRGB rgb;
		AvancementProjet ap;
		ChoixProjet cp;
		premierefenetre=new JFrame();
		premierefenetre.getContentPane().add(new ENTETEPAGE());
		//test.getContentPane().add(new CouleurChooser());
		premierefenetre.setSize(800, 400);
		premierefenetre.pack();
		premierefenetre.setVisible(true);
		
	    while(end==false){
	    	//frame.add(new CouleurRGB(),BorderLayout.CENTER);//ok
			//frame.add(new AvancementProjet(), BorderLayout.SOUTH);//ok
			//frame.add(new ChoixProjet(), BorderLayout.NORTH);//ok
			//frame.add(new PreVisualisation(), BorderLayout.WEST);
		    //frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    	//frame.setContentPane(new CouleurRGB());
	    	//frame.repaint();
		    //frame.pack();
		    //frame.setVisible(true);
	    int i=(JOptionPane.showConfirmDialog(null, "finni?"));
	    if(i==0){
	    	end=true;
	    }
	    }
	}

}
