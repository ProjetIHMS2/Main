package Menu_interfacePrincipales;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.AbstractAction;
import javax.swing.Action;

public class CouleurRGB extends JPanel implements ChangeListener, ActionListener,KeyListener{

	protected int r,g,b;
	protected JSlider slider_r,slider_g,slider_b;
	protected final int MIN=0,MAX=255;
	protected JTextField text,R_field,G_field,B_field,HEXA_field;
	protected TitledBorder titreR,titreG,titreB;
	protected JPanel zoneSaisieHEXAEtCheck;
	static final String SPACE_text="                           ";
	static final String SPACE_text_center="                                        ";
	protected JButton check;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private final Action action = new SwingAction();

	public CouleurRGB() {
		super(true);
		check=new JButton("OK");
		zoneSaisieHEXAEtCheck=new JPanel();
		this.r=MAX/2;
		this.g=MAX/2;
		this.b=MAX/2;
		slider_r = new JSlider(JSlider.HORIZONTAL, MIN, MAX, (int)MAX/2);
		slider_g = new JSlider(JSlider.HORIZONTAL, MIN, MAX, (int)MAX/2);
		slider_b = new JSlider(JSlider.HORIZONTAL, MIN, MAX, (int)MAX/2);
		R_field=new JTextField();
		G_field=new JTextField();
		B_field=new JTextField();
		R_field.setText("\t\t");
		G_field.setText("\t\t\t");
		B_field.setText("\t\t");
		HEXA_field=new JTextField("\t\t");
		
		//constraint
		slider_r.addChangeListener(this);
		slider_g.addChangeListener(this);
		slider_b.addChangeListener(this);
		R_field.addActionListener(this);
		G_field.addActionListener(this);
		B_field.addActionListener(this);
		check.addActionListener(this);
		


			text=new JTextField("\t\t \t\t\t\t\t\t\t\t");
			text.isMinimumSizeSet();
			text.setMinimumSize(new Dimension(800, 250));
			text.setBackground(Color.white);
			text.setEditable(false);
		zoneSaisieHEXAEtCheck.add(check, BorderLayout.NORTH);
		addKeyListener(this);
		titreR = BorderFactory.createTitledBorder("\tgamme des rouges");
		titreG = BorderFactory.createTitledBorder("\tgamme des verts");
		titreB = BorderFactory.createTitledBorder("\tgamme des bleus");
		slider_r.setBorder(titreR);
		slider_g.setBorder(titreG);
		slider_b.setBorder(titreB);
		slider_b.setSize(new Dimension(500, 250));
		slider_g.setSize(new Dimension(500, 250));
		slider_r.setSize(new Dimension(300, 250));
		
		textField = new JTextField();
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		
		JButton btnNewButton = new JButton("New button");
		btnNewButton.setAction(action);
		GroupLayout groupLayout = new GroupLayout(this);
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(Alignment.TRAILING, groupLayout.createSequentialGroup()
							.addComponent(slider_r, GroupLayout.PREFERRED_SIZE, 146, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addComponent(slider_g, GroupLayout.PREFERRED_SIZE, 151, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(slider_b, GroupLayout.PREFERRED_SIZE, 144, GroupLayout.PREFERRED_SIZE))
						.addComponent(text, GroupLayout.PREFERRED_SIZE, 447, GroupLayout.PREFERRED_SIZE))
					.addContainerGap())
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(29)
					.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addGap(77)
					.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED, 65, Short.MAX_VALUE)
					.addComponent(textField_2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addGap(24))
				.addGroup(groupLayout.createSequentialGroup()
					.addComponent(textField_4, GroupLayout.DEFAULT_SIZE, 453, Short.MAX_VALUE)
					.addContainerGap())
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(178)
							.addComponent(btnNewButton, GroupLayout.PREFERRED_SIZE, 89, GroupLayout.PREFERRED_SIZE))
						.addGroup(Alignment.LEADING, groupLayout.createSequentialGroup()
							.addGap(181)
							.addComponent(textField_3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap(196, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(4)
					.addComponent(text, GroupLayout.PREFERRED_SIZE, 46, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(slider_r, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(slider_b, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(slider_g, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(textField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(textField_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(textField_2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(34)
					.addComponent(textField_4, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(textField_3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addGap(43)
					.addComponent(btnNewButton)
					.addContainerGap())
		);
		setLayout(groupLayout);
	}
	public CouleurRGB(int r,int g,int b){
		this.r=r;
		this.g=g;
		this.b=b;
	}

	@Override
	public void stateChanged(ChangeEvent e) {
		JSlider source = (JSlider)e.getSource();
		text.setEnabled(false);
		text.setEditable(false);
		if(source.equals(slider_r)){
			this.r=slider_r.getValue();
			R_field.setText(SPACE_text+slider_r.getValue());
		}else if(source.equals(slider_g)){
			this.g=slider_g.getValue();
			G_field.setText(SPACE_text_center+slider_g.getValue());
		}else{
			this.b=slider_b.getValue();
			B_field.setText(SPACE_text+slider_b.getValue());
		}
		text.setBackground(new Color(this.r, this.g, this.b));
		text.repaint();
	}
	public CouleurRGB recupCouleur(){
		return new CouleurRGB(this.r,this.g,this.b);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		String r=sansEspaces(R_field.getText()),g=sansEspaces(G_field.getText()),b=sansEspaces(B_field.getText());
		System.err.println(r+"|"+g+"|"+b);
		if(e.getSource().equals(R_field)){
			slider_r.setValue(Integer.parseInt(r));
		}else if (e.getSource().equals(G_field)){
			slider_g.setValue(Integer.parseInt(g));
		}else if (e.getSource().equals(B_field)){
			slider_b.setValue(Integer.parseInt(b));
		}else if (e.getSource().equals(check)){
			setVisible(false);
		}
		
	}
	public static String sansEspaces(String str){
		String res="";
		for (int i = 0; i < str.length(); i++) {
			if(str.charAt(i) != ' ' && str.charAt(i)>='0'&& str.charAt(i) <='9'){
				res+=str.charAt(i);
			}
		}
		return res;
	}
	/**
	 * 
	 * @param colorStr e.g. "#FFFFFF"
	 * @return 
	 */
	public int getR() {
		return r;
	}
	public int getG() {
		return g;
	}
	public int getB() {
		return b;
	}
	@Override
	public void keyTyped(KeyEvent e) {
		System.err.println(e.getKeyCode());
		if(e.getKeyChar() == KeyEvent.VK_ENTER){
			setVisible(false);
		}
		
	}
	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "SwingAction");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
		}
	}
}
