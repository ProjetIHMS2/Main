package Menu_interfacePrincipales;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class AvancementProjet extends JPanel implements ChangeListener {
		JProgressBar avancement;
		final static int MAX=100;
		final static int MIN=0;
		public AvancementProjet() {
			// TODO Auto-generated constructor stub
			avancement=new JProgressBar(JProgressBar.HORIZONTAL, MIN, MAX);
			this.avancement.addChangeListener(this);
			this.avancement.setValue(50);
			add(avancement);
			setVisible(true);
		}	@Override
	public void stateChanged(ChangeEvent e) {
		
		if(e.getSource().equals(avancement)){
			this.avancement.setValue(60);
		}
		
	}
	public static void main(String[] args) {
		JFrame frame=new JFrame();
		frame.add(new AvancementProjet());
		frame.pack();
		frame.setVisible(true);
	}
	
	
}
