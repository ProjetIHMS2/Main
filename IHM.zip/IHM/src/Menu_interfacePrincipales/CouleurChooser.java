package Menu_interfacePrincipales;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import addIn.ENTETEPAGE;

public class CouleurChooser extends JPanel implements ActionListener{
	public static  Color c;
	protected JTextField View;
	protected JComboBox<String>liste;
	protected String[]content=new String[2];
	protected CouleurRGB rgbchooser;
	protected CouleurHEXA hexachooser;
	protected JPanel zone,main;
	protected Color[]recap=new Color[10];
	protected JFrame frame1;
	protected JFrame frame2;
	protected JButton bouton;
	protected JLabel mess=new JLabel("Choississez votre fa�on de choisir les couleurs");

	public CouleurChooser() {
		zone=new JPanel();
		main=new JPanel();
		frame1=new JFrame();
		frame1.setLayout(new BorderLayout());
		frame2=new JFrame();
		frame2.setLayout(new BorderLayout());
		bouton=new JButton("Terminer");
		main.setLayout(new BorderLayout());
		setLayout(new BorderLayout());
		View=new JTextField("\t\t\t");
		content[0]="CODE RGB | Palette";
		content[1]="CODE HEXA";
		liste=new JComboBox<>(content);
		zone.add(mess);
		main.add(View,BorderLayout.NORTH);
		main.add(liste,BorderLayout.CENTER);
		main.add(bouton, BorderLayout.EAST);
		//liste.addActionListener(this);
		liste.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        // Button specific code
		    	JComboBox cb= (JComboBox)e.getSource();
				String Name = (String)cb.getSelectedItem();		
					if(Name == (content[0])){
						System.err.println("RGB");
						frame2.setVisible(false);
						frame1.add(new CouleurRGB(),BorderLayout.CENTER);//ok
						frame1.add(new AvancementProjet(), BorderLayout.SOUTH);//ok
						frame1.add(new ChoixProjet(), BorderLayout.NORTH);//ok
						frame1.add(new PreVisualisation(), BorderLayout.WEST);
					    frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					    frame1.setLocationRelativeTo(null);	    	
				    	frame1.repaint();
					    frame1.pack();
					    frame1.setVisible(true);
					    frame1.setEnabled(false);
					}else if(Name == (content[1])){
						frame1.setVisible(false);
						frame2.add(new CouleurHEXA(),BorderLayout.CENTER);//ok
						frame2.add(new AvancementProjet(), BorderLayout.SOUTH);//ok
						frame2.add(new ChoixProjet(), BorderLayout.NORTH);//ok
						frame2.add(new PreVisualisation(), BorderLayout.WEST);
					    frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
					    frame2.setLocationRelativeTo(null);
				    	frame2.repaint();
					    frame2.pack();
					    frame2.setVisible(true);
					    frame2.setEnabled(false);
						System.err.println(CouleurChooser.c);
					}
					add(zone);
		    }
		});
		main.add(zone,BorderLayout.NORTH);
		//bouton.addActionListener(this);
		bouton.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        // Button specific code
		    	if(e.getSource().equals(bouton)){
		    		ENTETEPAGE.test.setVisible(false);
		    		frame1.setEnabled(true);
		    		frame2.setEnabled(true);
		    	}
		    }
		});
		setSize(800,500);
		add(main);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		
	}
}
