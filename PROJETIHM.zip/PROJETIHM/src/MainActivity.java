import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;

import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import Menu_interfacePrincipales.ChoixProjet;
import Menu_interfacePrincipales.Couleur;
import javax.swing.JTextPane;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import javax.swing.JSplitPane;
import java.awt.Insets;
//import com.jgoodies.forms.layout.FormLayout;
//import com.jgoodies.forms.layout.ColumnSpec;
//import com.jgoodies.forms.layout.RowSpec;
//import com.jgoodies.forms.factories.FormFactory;
import javax.swing.JToolBar;
import javax.swing.JButton;
import javax.swing.border.TitledBorder;
import javax.swing.JEditorPane;


public class MainActivity extends JFrame {

	private JPanel contentPane;
	private ChoixProjet cp;
	private JPanel PreviewZone;
	private JPanel panel_1;
	private JTextPane txtpnPreviewzone;
	private JPanel panel_2;
	private JPanel panel;
	private JPanel panel_3;
	private JToolBar toolBar;
	private JPanel panel_4;
	private JEditorPane editorPane;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainActivity frame = new MainActivity();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainActivity() {
		setType(Type.UTILITY);
		cp=new ChoixProjet();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1500, 1200);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		contentPane.add(cp, BorderLayout.NORTH);
		setContentPane(contentPane);
		
		PreviewZone = new JPanel();
		contentPane.add(PreviewZone, BorderLayout.WEST);
		/*PreviewZone.setLayout(new FormLayout(new ColumnSpec[] {
				ColumnSpec.decode("276px:grow"),},
			new RowSpec[] {
				RowSpec.decode("31px"),
				FormFactory.LINE_GAP_ROWSPEC,
				RowSpec.decode("660px:grow"),}));
		*/
		panel_1 = new JPanel();
		PreviewZone.add(panel_1, "1, 1, center, top");
		
		txtpnPreviewzone = new JTextPane();
		txtpnPreviewzone.setText("PreviewZone");
		panel_1.add(txtpnPreviewzone);
		
		panel_2 = new JPanel();
		panel_2.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		PreviewZone.add(panel_2, "1, 3, fill, fill");
		
		panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(new BorderLayout(0, 0));
		
		panel_3 = new JPanel();
		panel_3.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.add(panel_3, BorderLayout.EAST);
		
		toolBar = new JToolBar();
		panel_3.add(toolBar);
		
		panel_4 = new JPanel();
		panel_4.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.add(panel_4, BorderLayout.SOUTH);
		panel_4.setLayout(new BorderLayout(0, 0));
		
		editorPane = new JEditorPane();
		panel_4.add(editorPane, BorderLayout.NORTH);
		
		
	}

}
