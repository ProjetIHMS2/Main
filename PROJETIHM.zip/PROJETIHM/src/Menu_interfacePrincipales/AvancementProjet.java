package Menu_interfacePrincipales;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class AvancementProjet extends JPanel implements ChangeListener {
		JProgressBar avancement;
		final static int MAX=100;
		final static int MIN=0;
		public AvancementProjet() {
			// TODO Auto-generated constructor stub
			avancement=new JProgressBar(JProgressBar.HORIZONTAL, MIN, MAX);
			this.avancement.addChangeListener(this);
			this.avancement.setValue(50);
			this.avancement.setStringPainted(true);
			this.avancement.setForeground(new Color(0,0,255));
			this.avancement.setFont(new Font("Tahoma", Font.BOLD, 16));
			add(avancement);
			setVisible(true);
		}	@Override
	public void stateChanged(ChangeEvent e) {
		
		//if(e.getSource().equals(avancement)){
			//this.avancement.setValue(50);
		//}
		
	}
	public void BarChange(int changement){
		this.avancement.setValue(changement);
	}
	public static void main(String[] args) {
		JFrame frame=new JFrame();
		frame.add(new AvancementProjet());
		frame.pack();
		frame.setVisible(true);
	}
	
	
}
