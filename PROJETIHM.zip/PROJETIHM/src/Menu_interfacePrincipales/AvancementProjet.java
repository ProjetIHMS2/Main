package Menu_interfacePrincipales;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class AvancementProjet extends JPanel  {
		JProgressBar avancement;
		final static int MAX=800;
		final static int MIN=0;
		public AvancementProjet() {
			// TODO Auto-generated constructor stub
			avancement=new JProgressBar(JProgressBar.HORIZONTAL, MIN, MAX);
			this.avancement.setValue(50*8);
			this.avancement.setStringPainted(true);
			this.avancement.setForeground(new Color(0,0,255));
			this.avancement.setFont(new Font("Tahoma", Font.BOLD, 16));
			add(avancement);
			setVisible(true);
		}	public void setchange(int value){
			avancement.setValue(value);
		}
	public static void main(String[] args) {
		JFrame frame=new JFrame();
		frame.add(new AvancementProjet());
		frame.pack();
		frame.setVisible(true);
		
	}
	
	
}
