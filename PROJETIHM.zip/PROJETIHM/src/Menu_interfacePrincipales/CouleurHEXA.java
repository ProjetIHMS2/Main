package Menu_interfacePrincipales;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class CouleurHEXA extends JPanel implements ActionListener{
		protected String Saisie_Hexa;
		protected JButton checkHexa;
		protected JTextField Zone_Saisie_HEXA,TITLE;
		
		 public CouleurHEXA() {
			Saisie_Hexa="";
			TITLE=new JTextField("           CHOIX AVEC CODE HEXADECIMAL");
			checkHexa=new JButton("OK");
			Zone_Saisie_HEXA=new JTextField("\t\t\t");
			
			//ajout de components 
			setLayout(new BorderLayout());
			add(TITLE,BorderLayout.NORTH);
			add(Zone_Saisie_HEXA,BorderLayout.CENTER);
			add(checkHexa,BorderLayout.SOUTH);
			System.err.println(this.getLayout());

			
			//Config taille et autres
			TITLE.setEditable(false);
			Zone_Saisie_HEXA.setText(CouleurRGB.SPACE_text_center);
			
		}
		@Override
		public void actionPerformed(ActionEvent e) {
			if(e.getSource().equals(checkHexa)){
				System.out.println("sa rentre");
				String tmp=checkHexa.getText();
				CouleurChooser.c=hex2Rgb(tmp);
			}else if(e.getSource().equals(checkHexa)){
				System.err.println("k");
				setVisible(false);
			}
			
		}
		public static Color hex2Rgb(String colorStr) {
		    return new Color(
		            Integer.valueOf( colorStr.substring( 1, 3 ), 16 ),
		            Integer.valueOf( colorStr.substring( 3, 5 ), 16 ),
		            Integer.valueOf( colorStr.substring( 5, 7 ), 16 ) );
		}
		@Override
		public String toString() {
		return super.toString();
		}
		public static void main(String[] args) {
			JFrame test=new JFrame();
			test.getContentPane().add(new CouleurHEXA());
			test.pack();
			test.setVisible(true);
		}
}
