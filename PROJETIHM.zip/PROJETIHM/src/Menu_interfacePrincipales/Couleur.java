package Menu_interfacePrincipales;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class Couleur extends JPanel implements ChangeListener, ActionListener{
	protected int r,g,b;
	protected JSlider slider_r,slider_g,slider_b;
	protected Color c;
	protected final int MIN=0,MAX=255;
	protected JTextField text,R_field,G_field,B_field,HEXA_field;
	protected TitledBorder titreR,titreG,titreB;
	protected JPanel zoneSaisieRGB,zoneSaisieHEXAEtCheck;
	static final String SPACE_text="                           ";
	static final String SPACE_text_center="                                        ";
	protected JButton check;

	public Couleur(int r,int g,int b){
		this.r=r;
		this.g=g;
		this.b=b;
	}
	public Couleur() {
		super(true);
		check=new JButton("OK");
		zoneSaisieRGB=new JPanel();
		zoneSaisieHEXAEtCheck=new JPanel();
		this.r=MAX/2;
		this.g=MAX/2;
		this.b=MAX/2;
		this.setLayout(new BorderLayout());
		slider_r = new JSlider(JSlider.HORIZONTAL, MIN, MAX, (int)MAX/2);
		slider_g = new JSlider(JSlider.HORIZONTAL, MIN, MAX, (int)MAX/2);
		slider_b = new JSlider(JSlider.HORIZONTAL, MIN, MAX, (int)MAX/2);
		R_field=new JTextField();
		G_field=new JTextField();
		B_field=new JTextField();
		R_field.setText("\t\t");
		G_field.setText("\t\t\t");
		B_field.setText("\t\t");
		HEXA_field=new JTextField("\t\t");
		
		//constraint
		slider_r.addChangeListener(this);
		slider_g.addChangeListener(this);
		slider_b.addChangeListener(this);
		R_field.addActionListener(this);
		G_field.addActionListener(this);
		B_field.addActionListener(this);
		check.addActionListener(this);



		add(slider_r, BorderLayout.WEST);
		add(slider_g, BorderLayout.CENTER);
		add(slider_b, BorderLayout.EAST);
		zoneSaisieRGB.add(R_field, FlowLayout.LEFT);
		zoneSaisieRGB.add(G_field, FlowLayout.CENTER);
		zoneSaisieRGB.add(B_field, FlowLayout.RIGHT);
		zoneSaisieHEXAEtCheck.add(HEXA_field,BorderLayout.CENTER);
		zoneSaisieHEXAEtCheck.add(check, BorderLayout.NORTH);
		add(zoneSaisieRGB,BorderLayout.SOUTH);
	


		text=new JTextField();
		text.setMinimumSize(new Dimension(800, 250));
		text.setBackground(Color.white);
		add(text, BorderLayout.NORTH);
		titreR = BorderFactory.createTitledBorder("\tgamme des rouges");
		titreG = BorderFactory.createTitledBorder("\tgamme des verts");
		titreB = BorderFactory.createTitledBorder("\tgamme des bleus");
		slider_r.setBorder(titreR);
		slider_g.setBorder(titreG);
		slider_b.setBorder(titreB);
	}

	@Override
	public void stateChanged(ChangeEvent e) {
		JSlider source = (JSlider)e.getSource();
		text.setEnabled(false);
		text.setEditable(false);
		if(source.equals(slider_r)){
			this.r=slider_r.getValue();
			R_field.setText(SPACE_text+slider_r.getValue());
		}else if(source.equals(slider_g)){
			this.g=slider_g.getValue();
			G_field.setText(SPACE_text_center+slider_g.getValue());
		}else{
			this.b=slider_b.getValue();
			B_field.setText(SPACE_text+slider_b.getValue());
		}
		text.setBackground(new Color(this.r, this.g, this.b));
		text.repaint();
	}
	public Couleur recupCouleur(){
		return new Couleur(this.r,this.g,this.b);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		String r=sansEspaces(R_field.getText()),g=sansEspaces(G_field.getText()),b=sansEspaces(B_field.getText());
		System.err.println(r+"|"+g+"|"+b);
		if(e.getSource().equals(R_field)){
			slider_r.setValue(Integer.parseInt(r));
		}else if (e.getSource().equals(G_field)){
			slider_g.setValue(Integer.parseInt(g));
		}else if (e.getSource().equals(B_field)){
			slider_b.setValue(Integer.parseInt(b));
		}else if (e.getSource().equals(HEXA_field)){
			
		}
		
	}
	public String sansEspaces(String str){
		String res="";
		for (int i = 0; i < str.length(); i++) {
			if(str.charAt(i) != ' ' && str.charAt(i)>='0'&& str.charAt(i) <='9'){
				res+=str.charAt(i);
			}
		}
		return res;
	}
	/**
	 * 
	 * @param colorStr e.g. "#FFFFFF"
	 * @return 
	 */
	public static Color hex2Rgb(String colorStr) {
	    return new Color(
	            Integer.valueOf( colorStr.substring( 1, 3 ), 16 ),
	            Integer.valueOf( colorStr.substring( 3, 5 ), 16 ),
	            Integer.valueOf( colorStr.substring( 5, 7 ), 16 ) );
	}




}
