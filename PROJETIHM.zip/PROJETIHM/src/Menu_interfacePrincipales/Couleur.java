package Menu_interfacePrincipales;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class Couleur extends JPanel implements ChangeListener, MouseListener{
	protected int r,g,b;
	protected JSlider slider_r,slider_g,slider_b;
	protected Color c;
	protected final int MIN=0,MAX=255;
	protected JTextField text;
	protected TitledBorder titreR,titreG,titreB;


	public Couleur(int r,int g,int b){
		this.r=r;
		this.g=g;
		this.b=b;
	}
	public Couleur() {

		super(true);
		this.r=MAX/2;
		this.g=MAX/2;
		this.b=MAX/2;
		this.setLayout(new BorderLayout());
		slider_r = new JSlider(JSlider.HORIZONTAL, MIN, MAX, (int)MAX/2);
		slider_g = new JSlider(JSlider.HORIZONTAL, MIN, MAX, (int)MAX/2);
		slider_b = new JSlider(JSlider.HORIZONTAL, MIN, MAX, (int)MAX/2);
		//setter des ticks
		//slider_r
		slider_r.setMinorTickSpacing(2);
		slider_r.setMajorTickSpacing(50);
		//slider_g
		slider_g.setMinorTickSpacing(2);
		slider_g.setMajorTickSpacing(50);
		//slider_b
		slider_b.setMinorTickSpacing(2);
		slider_b.setMajorTickSpacing(50);
		//painting
		slider_r.setPaintTicks(true);
		slider_r.setPaintLabels(true);
		slider_g.setPaintTicks(true);
		slider_g.setPaintLabels(true);
		slider_b.setPaintTicks(true);
		slider_b.setPaintLabels(true);
		slider_r.addChangeListener(this);
		slider_g.addChangeListener(this);
		slider_b.addChangeListener(this);



		add(slider_r, BorderLayout.WEST);
		add(slider_g, BorderLayout.CENTER);
		add(slider_b, BorderLayout.EAST);

		//Jlabel

		text=new JTextField();
		text.setPreferredSize((new Dimension(50, 50)));
		text.setBackground(Color.white);
		add(text, BorderLayout.NORTH);
		titreR = BorderFactory.createTitledBorder("gamme des rouges");
		titreG = BorderFactory.createTitledBorder("gamme des verts");
		titreB = BorderFactory.createTitledBorder("gamme des bleus");
		slider_r.setBorder(titreR);
		slider_g.setBorder(titreG);
		slider_b.setBorder(titreB);
	}

	@Override
	public void stateChanged(ChangeEvent e) {
		JSlider source = (JSlider)e.getSource();
		if(source.equals(slider_r)){
			this.r=slider_r.getValue();
		}else if(source.equals(slider_g)){
			this.g=slider_g.getValue();
		}else{
			this.b=slider_b.getValue();
		}
		text.setBackground(new Color(this.r, this.g, this.b));
		text.repaint();
	}
	public Couleur recupCouleur(){
		return new Couleur(this.r,this.g,this.b);
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub

	}



}
