package Menu_interfacePrincipales;

import java.awt.Color;

public class NiveauDeGris extends Color{
	 static int r,g,b;
	  
	
	public NiveauDeGris() {
		super(1);
	}
	public static  Color export(Color c){
		r= (int) (0.3 * c.getRed());
		g=(int) 0.59 * c.getGreen();
		b=(int) 0.11 * c.getBlue();
		return new Color(r,g,b);
	}
	/*
NiveauGris = 0.3   Rouge + 0.59   Vert + 0.11   Bleu 
*/
}
