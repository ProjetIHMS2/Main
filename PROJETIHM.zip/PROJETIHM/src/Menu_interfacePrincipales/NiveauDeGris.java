package Menu_interfacePrincipales;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JTextField;

public class NiveauDeGris extends Color{
	 static int NiveauDeGris; 
	
	public NiveauDeGris() {
		super(1);
	}
	public static  Color export(Color c){
		NiveauDeGris= (int) (0.3*c.getRed()+0.59*c.getGreen() + 0.11*c.getBlue());
		return new Color(NiveauDeGris,NiveauDeGris,NiveauDeGris);
	}
	
	
}
