package Menu_interfacePrincipales;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class ChoixProjet extends JPanel implements ActionListener {
	/**
	 * @author brisseta
	 * {@link}voir interface Projet
	 * @version A faire : Flow layout a inclure  a la fenetre principale 
	 * 
	 */
	private static final long serialVersionUID = 166644444444168499L;
	protected JCheckBox checkbox_Graph;
	protected JCheckBox checkbox_Agenda;
	protected int choix; //1 pour Graphique 2 pour Agenda

	/*---------------------------Builder-------------------------------*/

	public ChoixProjet() {
		this.checkbox_Graph=new JCheckBox(new ImageIcon("images/graph.png"), false);
		this.checkbox_Agenda=new JCheckBox(new ImageIcon("images/agenda.png"), false);
		checkbox_Agenda.setBorder(BorderFactory.createTitledBorder("Projet d'agenda"));
		checkbox_Graph.setBorder(BorderFactory.createTitledBorder("Projet de Graph"));
		checkbox_Agenda.addActionListener(this);
		checkbox_Graph.addActionListener(this);
		setBorder(BorderFactory.createTitledBorder("chosi ton projet"));
		add(checkbox_Agenda,BorderLayout.WEST);
		add(checkbox_Graph, BorderLayout.EAST);
		setVisible(true);

	}

	/*---------------------------Methodes-------------------------------*/

	@Override
	public void actionPerformed(ActionEvent e) {
		//TODO
		if(e.getSource().equals(checkbox_Agenda)){
			System.out.println("c'est un agenda //TODO");
			//TODO action a faire
		}else if(e.getSource().equals(checkbox_Graph)){
			System.out.println("c'est un Graph //TODO");
			//TODO action a faire
		}else{
			System.err.println("aucune reaction");
			//TODO action a faire 
		}

	}
	public static void main(String[] args) {
		JFrame test=new JFrame("Fenetre de test ");
		test.add(new ChoixProjet());
		test.pack();
		test.setVisible(true);
	}
}
