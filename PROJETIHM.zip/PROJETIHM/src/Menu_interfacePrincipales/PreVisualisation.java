package Menu_interfacePrincipales;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.w3c.dom.events.EventTarget;
import org.w3c.dom.events.MouseEvent;
import org.w3c.dom.views.AbstractView;

import addIn.ENTETEPAGE;

public class PreVisualisation extends JPanel implements ActionListener,MouseListener {
	
	protected JTextField cadre;
	protected JPanel zone;
	protected JPanel uneSocket;
	protected Couleur couleurTMP;
	protected NiveauDeGris niv;
	protected ArrayList<JPanel>listeChoisie;
	//protected ArrayList
	protected HashMap< Couleur,NiveauDeGris >MAP_VISIBLE;
	public static int nbCouleurs=20;
	
	private static final long serialVersionUID = 1L;
	 
		public PreVisualisation(int nb) {
			/*gestion des cadres intermediaires */
			zone=new JPanel();
			zone.setLayout(new GridLayout(0, 2));
			MAP_VISIBLE=new HashMap<>();
			listeChoisie=new ArrayList<>();
			
			for (int i = 0; i < (nb)*2; i++) {
				couleurTMP=new Couleur();
				//niv=new NiveauDeGris(couleurTMP);
				MAP_VISIBLE.put(couleurTMP,niv);
				/*Prerequis Jpanel */
				uneSocket=new JPanel();//TODO Listener
				/*DEFF CADRE */
				cadre=new JTextField();
				cadre.setPreferredSize(new Dimension(75,75));
				cadre.isPreferredSizeSet();
				cadre.setEditable(false);
				uneSocket.add(cadre,BorderLayout.EAST);
				uneSocket.add(cadre,BorderLayout.WEST);
				
				listeChoisie.add(uneSocket);
				zone.add(listeChoisie.get(i));
				cadre.addActionListener(this);
				cadre.addMouseListener(this);
				//uneSocket.addACtionListener(this);
				uneSocket.addMouseListener(this);
				cadre.setBackground(Color.RED);
				
				
			}
			add(zone);
			setVisible(true);
			
		}

		@Override
		public void actionPerformed(ActionEvent e) {
		}
		public int  Remove(JPanel j){
			int cpt=0;
			for (JPanel tmp : listeChoisie) {
				if(tmp.equals(j)){
					return cpt;
				}
				cpt++;
			}
			return -1;
		}
		@Override
		public void mouseClicked(java.awt.event.MouseEvent e) {
			// TODO Auto-generated method stub
			System.out.println("toto");
				if(e.getSource() instanceof JTextField){
					JTextField tmp=(JTextField)e.getSource();
					String[] options = new String[] {"Modifier", "Supprimer","cancel"};
				    int reponse = JOptionPane.showOptionDialog(null, "Quelle Action voulez-vous effectuer ?", "Action demande",
				        JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE,
				        null, options, options[0]);
				    if(reponse == 0){
				    	System.out.println("modif");
				    }else if(reponse == 1){
				    	tmp.setBackground(Color.white);
				    }
					
			}
		}
		@Override
		public void mousePressed(java.awt.event.MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
		@Override
		public void mouseReleased(java.awt.event.MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
		@Override
		public void mouseEntered(java.awt.event.MouseEvent e) {
			// TODO Auto-generated method stub
			
		}
		@Override
		public void mouseExited(java.awt.event.MouseEvent e) {
			// TODO Auto-generated method stub
			
		}


		
}
