package Menu_interfacePrincipales;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class MenuPrincipal extends JPanel implements ActionListener,MouseListener{

	protected JPanel panel;
	 protected boolean panel_Vision;
	 protected JPanel projectSelector;
	 protected boolean projectSelector_Vision;
	 protected JCheckBox choix;
	 protected boolean choix_Vision;
	 
	 public MenuPrincipal() {
		panel=new JPanel();
		projectSelector=new JPanel();
		choix=new JCheckBox("");
	}
	 public void televerser() {
		//Main.frame.add(this.panel);
		//Main.frame.add(this.projectSelector);
		
	}
	 public boolean estVisible_Panel_Vision() {
			return panel_Vision;
		}
		public void setPanel_Vision(boolean panel_Vision) {
			this.panel_Vision = panel_Vision;
		}
		public JPanel getProjectSelector() {
			return projectSelector;
		}
		public void setProjectSelector(JPanel projectSelector) {
			this.projectSelector = projectSelector;
		}
		public boolean estVisible_ProjectSelector_Vision() {
			return projectSelector_Vision;
		}
		public void setProjectSelector_Vision(boolean projectSelector_Vision) {
			this.projectSelector_Vision = projectSelector_Vision;
		}
		public JCheckBox getChoix() {
			return choix;
		}
		public void setChoix(JCheckBox choix) {
			this.choix = choix;
		}
		public boolean estVisible_Choix_Vision() {
			return choix_Vision;
		}
		public void setChoix_Vision(boolean choix_Vision) {
			this.choix_Vision = choix_Vision;
		}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

}
