package Menu_interfacePrincipales;

import javax.swing.JFrame;

public class MainActivity extends JFrame {

	/**
	 * <h1>Ceci est notre Activit�e principale </h1>
	 * <h3> Elle g�re la visibilit� et les etapes de toutes ces JPanel </h3>
	 * @author brisseta
	 * @see Couleur ChoixProjet PreVisualisation
	 */
	private static final long serialVersionUID = 14651848646811L;
	
	

}
