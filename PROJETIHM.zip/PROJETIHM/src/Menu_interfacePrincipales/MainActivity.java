package Menu_interfacePrincipales;
import java.awt.BorderLayout;
import Menu_interfacePrincipales.*;
import java.awt.Dimension;
import java.awt.EventQueue;

import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextPane;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import javax.swing.JSplitPane;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JToolBar;
import javax.swing.JButton;
import javax.swing.border.TitledBorder;
import javax.swing.JEditorPane;
import addIn.*;

public class MainActivity extends JFrame implements ActionListener {

	public static JPanel contentPane;
	public static JPanel PreviewZone;
	public static JPanel panel_1;
	public static JPanel panel_2;
	public static JPanel panel;
	public static JPanel panel_3;
	public static JToolBar toolBar;
	public static JPanel panel_4;
	public static AvancementProjet avancementProjet;
	public static ENTETEPAGE EntetePage;
	public static CouleurChooser colorChooser;
	public static PreVisualisation preview;





	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainActivity frame = new MainActivity();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainActivity() {
		setType(Type.UTILITY);
		EntetePage=new ENTETEPAGE();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1500, 1200);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		contentPane.add(EntetePage, BorderLayout.NORTH);
		setContentPane(contentPane);

		PreviewZone = new JPanel();
		contentPane.add(PreviewZone, BorderLayout.WEST);

		panel_1 = new JPanel();
		preview=new PreVisualisation(10);
		panel_1.add(preview);
		PreviewZone.add(panel_1, "1, 1, center, top");

		panel_2 = new JPanel();
		panel_2.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		PreviewZone.add(panel_2, "1, 3, fill, fill");

		panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		colorChooser=new CouleurChooser();
		panel.add(colorChooser);
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(new BorderLayout(0, 0));

		panel_3 = new JPanel();
		panel_3.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.add(panel_3, BorderLayout.EAST);

		toolBar = new JToolBar();
		panel_3.add(toolBar);

		panel_4 = new JPanel();
		panel.add(panel_4, BorderLayout.SOUTH);
		panel_4.setLayout(new BorderLayout(0, 0));



	}

	@Override
	public void actionPerformed(ActionEvent e) {
		repaint();
		validate();
	}


}
