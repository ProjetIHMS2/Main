package Menu_interfacePrincipales;
import java.awt.BorderLayout;
import java.awt.Color;

import Menu_interfacePrincipales.*;
import java.awt.Dimension;
import java.awt.EventQueue;

import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextPane;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import javax.swing.JSplitPane;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JToolBar;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.border.TitledBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.plaf.SliderUI;
import javax.swing.JEditorPane;
import addIn.*;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import java.awt.CardLayout;
import javax.swing.JSlider;
import javax.swing.UIManager;
import javax.swing.LayoutStyle.ComponentPlacement;

public class MainActivity extends JFrame implements ActionListener,ChangeListener,KeyListener {

	public static JPanel contentPane;
	public static JPanel PreviewZone;
	public static JPanel panel_1;
	public static JPanel panel;
	public static ENTETEPAGE EntetePage;
	public static CouleurChooser colorChooser;
	public static PreVisualisation preview;
	static  JPanel content_center;
	protected JPanel zone_content_center;
	protected CouleurHEXA hexachooser;
	protected JPanel zone,main;
	protected Color[]recap=new Color[10];
	protected JLabel mess=new JLabel("Choississez votre fa�on de choisir les couleurs");
	private JTextField preview_Zone;
	private JTextField hexa_type;
	private JTextField Title_Hexa;
	private JTextField R_field;
	private JTextField G_field;
	private JTextField B_field;
	protected JTextField text;
	private JSlider R_slider;
	private JSlider G_slider;
	private JSlider B_slider;
	private JButton color_check;
	static final String SPACE_text="                ";
	static final String SPACE_text_center="                ";
	protected int r,g,b;
	protected final int MIN=0,MAX=255;
	private JButton checkHexa=new JButton("Valider hexa");
	static Color tmp;
	static  JTextField cadre_tmp;
	static int index_cadre_tmp;
	



	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainActivity frame = new MainActivity();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainActivity() {
		setType(Type.UTILITY);
		EntetePage=new ENTETEPAGE();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1500, 1000);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		contentPane.add(EntetePage, BorderLayout.NORTH);
		setContentPane(contentPane);

		PreviewZone = new JPanel();
		contentPane.add(PreviewZone, BorderLayout.WEST);

		panel_1 = new JPanel();
		preview=new PreVisualisation(10);
		panel_1.add(preview);
		PreviewZone.add(panel_1, "1, 1, center, top");
		/** TODO **/
		content_center=new JPanel();
		zone_content_center=new JPanel();
		zone_content_center.setForeground(Color.ORANGE);
		zone_content_center.setBackground(Color.LIGHT_GRAY);
		zone_content_center.setSize(500, 500);
		hexachooser=new CouleurHEXA();
		contentPane.add(content_center);
		GroupLayout gl_content_center = new GroupLayout(content_center);
		gl_content_center.setHorizontalGroup(
			gl_content_center.createParallelGroup(Alignment.LEADING)
				.addComponent(zone_content_center, GroupLayout.PREFERRED_SIZE, 1255, GroupLayout.PREFERRED_SIZE)
		);
		gl_content_center.setVerticalGroup(
			gl_content_center.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_content_center.createSequentialGroup()
					.addComponent(zone_content_center, GroupLayout.PREFERRED_SIZE, 841, GroupLayout.PREFERRED_SIZE)
					.addGap(23))
		);
		
		preview_Zone = new JTextField();
		preview_Zone.setColumns(10);
		
		R_slider = new JSlider(JSlider.HORIZONTAL, MIN, MAX, (int)MAX/2);
		R_slider.setBorder(new TitledBorder(null, "zone Rouge", TitledBorder.CENTER, TitledBorder.TOP, null, null));
		
		G_slider = new JSlider(JSlider.HORIZONTAL, MIN, MAX, (int)MAX/2);
		G_slider.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "zone Vert", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(0, 0, 0)));
		
		B_slider = new JSlider(JSlider.HORIZONTAL, MIN, MAX, (int)MAX/2);
		B_slider.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "zone Bleue", TitledBorder.CENTER, TitledBorder.TOP, null, new Color(0, 0, 0)));
		
		color_check = new JButton("OK");
		
		hexa_type = new JTextField();
		hexa_type.setColumns(10);

		zone_content_center.setForeground(Color.ORANGE);
		Title_Hexa = new JTextField();
		Title_Hexa.setText("           HEXADECIMAL");
		Title_Hexa.setColumns(10);
		
		R_field = new JTextField();
		R_field.setColumns(10);
		
		G_field = new JTextField();
		G_field.setColumns(10);
		
		B_field = new JTextField();
		B_field.setColumns(10);
		R_slider.addChangeListener(this);
		G_slider.addChangeListener(this);
		B_slider.addChangeListener(this);
		R_field.addActionListener(this);
		G_field.addActionListener(this);
		B_field.addActionListener(this);
		color_check.addActionListener(this);
		checkHexa.addActionListener(this);
		checkHexa.setFocusable(false);
		color_check.setFocusable(false);
		checkHexa.setForeground(Color.orange);
		checkHexa.setBackground(Color.black);
		color_check.setForeground(Color.orange);
		color_check.setBackground(Color.black);
		addKeyListener(this);
		
		
		GroupLayout gl_zone_content_center = new GroupLayout(zone_content_center);
		gl_zone_content_center.setHorizontalGroup(
			gl_zone_content_center.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_zone_content_center.createSequentialGroup()
					.addContainerGap()
					.addComponent(preview_Zone, GroupLayout.DEFAULT_SIZE, 1245, Short.MAX_VALUE))
				.addGroup(gl_zone_content_center.createSequentialGroup()
					.addGap(511)
					.addComponent(color_check, GroupLayout.PREFERRED_SIZE, 159, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(585, Short.MAX_VALUE))
				.addGroup(gl_zone_content_center.createSequentialGroup()
					.addGap(20)
					.addComponent(R_slider, GroupLayout.PREFERRED_SIZE, 331, GroupLayout.PREFERRED_SIZE)
					.addGap(44)
					.addGroup(gl_zone_content_center.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_zone_content_center.createSequentialGroup()
							.addComponent(hexa_type, GroupLayout.PREFERRED_SIZE, 330, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(checkHexa))
						.addGroup(gl_zone_content_center.createSequentialGroup()
							.addComponent(G_slider, GroupLayout.PREFERRED_SIZE, 350, GroupLayout.PREFERRED_SIZE)
							.addGap(32)
							.addComponent(B_slider, GroupLayout.PREFERRED_SIZE, 358, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap(120, Short.MAX_VALUE))
				.addGroup(gl_zone_content_center.createSequentialGroup()
					.addGap(500)
					.addComponent(Title_Hexa, GroupLayout.PREFERRED_SIZE, 137, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(618, Short.MAX_VALUE))
				.addGroup(gl_zone_content_center.createSequentialGroup()
					.addGap(138)
					.addComponent(R_field, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addGap(305)
					.addComponent(G_field, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED, 300, Short.MAX_VALUE)
					.addComponent(B_field, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addGap(254))
		);
		gl_zone_content_center.setVerticalGroup(
			gl_zone_content_center.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_zone_content_center.createSequentialGroup()
					.addComponent(preview_Zone, GroupLayout.PREFERRED_SIZE, 105, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addGroup(gl_zone_content_center.createParallelGroup(Alignment.LEADING)
						.addComponent(B_slider, GroupLayout.PREFERRED_SIZE, 49, GroupLayout.PREFERRED_SIZE)
						.addComponent(G_slider, GroupLayout.PREFERRED_SIZE, 49, GroupLayout.PREFERRED_SIZE)
						.addComponent(R_slider, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_zone_content_center.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_zone_content_center.createSequentialGroup()
							.addGroup(gl_zone_content_center.createParallelGroup(Alignment.LEADING)
								.addComponent(R_field, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(G_field, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
							.addPreferredGap(ComponentPlacement.RELATED, 162, Short.MAX_VALUE)
							.addComponent(Title_Hexa, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addGroup(gl_zone_content_center.createParallelGroup(Alignment.BASELINE)
								.addComponent(hexa_type, GroupLayout.PREFERRED_SIZE, 69, GroupLayout.PREFERRED_SIZE)
								.addComponent(checkHexa))
							.addGap(181)
							.addComponent(color_check, GroupLayout.PREFERRED_SIZE, 80, GroupLayout.PREFERRED_SIZE)
							.addGap(120))
						.addGroup(gl_zone_content_center.createSequentialGroup()
							.addComponent(B_field, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addContainerGap())))
		);
		zone_content_center.setLayout(gl_zone_content_center);
		content_center.setLayout(gl_content_center);
		content_center.setVisible(false);
		contentPane.setBackground(Color.DARK_GRAY);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		String r=sansEspaces(R_field.getText()),g=sansEspaces(G_field.getText()),b=sansEspaces(B_field.getText());
		System.err.println(r+"|"+g+"|"+b);
		if(e.getSource().equals(R_field)){
			R_slider.setValue(Integer.parseInt(r));
		}else if (e.getSource().equals(G_field)){
			G_slider.setValue(Integer.parseInt(g));
		}else if (e.getSource().equals(B_field)){
			B_slider.setValue(Integer.parseInt(b));
		}else if (e.getSource().equals(color_check)){
			tmp=new Color(R_slider.getValue(),G_slider.getValue(),B_slider.getValue());
			System.out.println(tmp.toString());
			content_center.setVisible(false);
			tmp=preview_Zone.getBackground();
			MainActivity.cadre_tmp.setBackground(MainActivity.tmp);
			
			//ON A UNE HASHMAP QUI NOUS DONNE LES INDICES 
			//LES INDICES IMPAIR CORRESPONDENT AUX JTEXTFIELD DE DROITE DONC POUR LE NIV DE GRIS
			//DONC QUAND ON CLIQUE SUR LE BOUTON OK, ON RECUPERE L'INDICE DU JTEXTFIELD DE GAUCHE OU ON MET LA COULEUR
			//ON FAIT +1 A CET INDICE ET ON MET EN MEME TEMPS LE NIVEAU DE GRIS SUR LE JTEXTFIELD DE DROITE
			
			
		}else if(e.getSource().equals(checkHexa)){
			System.out.println("sa rentre");
			String hexa_text=hexa_type.getText();
			CouleurChooser.c=hex2Rgb(sansEspaces(hexa_text));
			preview_Zone.setBackground(CouleurChooser.c);
			
		}
		
		
	
	}
	public static Color hex2Rgb(String colorStr) {
	    return new Color(
	            Integer.valueOf( colorStr.substring( 1, 3 ), 16 ),
	            Integer.valueOf( colorStr.substring( 3, 5 ), 16 ),
	            Integer.valueOf( colorStr.substring( 5, 7 ), 16 ) );
	}
	public static String sansEspaces(String str){
		String res="";
		for (int i = 0; i < str.length(); i++) {
			if(str.charAt(i) != ' ' && str.charAt(i)>='0'&& str.charAt(i) <='9'){
				res+=str.charAt(i);
			}
		}
		return res;
	}
	public String hexaTovalid(String tmp) throws NumberFormatException{
		String res="";
		for (int i = 0; i < tmp.length(); i++) {
			if(tmp.charAt(i) >=0 && tmp.charAt(i) <=9){
			}else{
			res += tmp.charAt(i);
			}
		}
		System.err.println(res);
		return res;
	}

	@Override
	public void stateChanged(ChangeEvent e) {
		JSlider source = (JSlider)e.getSource();
		preview_Zone.setEnabled(false);
		preview_Zone.setEditable(false);
		if(source.equals(R_slider)){
			this.r=R_slider.getValue();
			R_field.setText(SPACE_text+R_slider.getValue());
		}else if(source.equals(G_slider)){
			this.g=G_slider.getValue();
			G_field.setText(SPACE_text_center+G_slider.getValue());
		}else{
			this.b=B_slider.getValue();
			B_field.setText(SPACE_text+B_slider.getValue());
		}
		preview_Zone.setBackground(new Color(this.r, this.g, this.b));
		preview_Zone.repaint();
		
	}
	
	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		if(e.getKeyChar() == KeyEvent.VK_ENTER){
			setVisible(false);
		}
	}
}
