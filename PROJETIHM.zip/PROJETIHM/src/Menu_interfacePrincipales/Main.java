package Menu_interfacePrincipales;

import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.ImageIcon;
import javax.swing.JColorChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Main {
	public static JFrame frame;

	public static void main(String[] args) {
		boolean end=false;
		MenuPrincipal menu=new MenuPrincipal();
		ImageIcon background=new ImageIcon("images/bg.png");
		Couleur c=new Couleur();
		JFrame frame = new JFrame("Make your Color" );
		JFrame frame2=new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		while(!end){
			frame.add(c);
			PreVisualisation test=new PreVisualisation();
			frame2.add(test,BorderLayout.AFTER_LAST_LINE);
			frame.repaint();
			frame2.pack();
			frame.pack();
			frame.setVisible(true);
			frame2.setVisible(true);
			int i=(JOptionPane.showConfirmDialog(null, "finni?"));
			if(i==0){
				end=true;
			}
		}
	}

}
