package Menu_interfacePrincipales;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Main {
	 public static JFrame frame;
	 
	public static void main(String[] args) {
		boolean end=false;
		MenuPrincipal menu=new MenuPrincipal();
		ImageIcon background=new ImageIcon("images/bg.png");
		Couleur c=new Couleur();
		JFrame frame = new JFrame("Make your Color" );
	    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    while(end==false){
	    	frame.setContentPane(c);
	    	frame.repaint();
		    frame.pack();
		    frame.setVisible(true);
	    int i=(JOptionPane.showConfirmDialog(null, "finni?"));
	    if(i==0){
	    	end=true;
	    }
	    }
	}

}
