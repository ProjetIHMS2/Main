package Menu_interfacePrincipales;

public class Agenda implements Projet{

	@Override
	public boolean convientAuclient() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int NiveauDavancement(int nbTachesFinnies) {
		// TODO Auto-generated method stub
		return 0;
	}

}
