package Menu_interfacePrincipales;

public interface Projet {

	public boolean convientAuclient();
	
	public int NiveauDavancement(int nbTachesFinnies);
	
	
	
}