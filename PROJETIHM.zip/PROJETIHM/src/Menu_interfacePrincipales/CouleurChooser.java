package Menu_interfacePrincipales;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import addIn.ENTETEPAGE;

public class CouleurChooser extends JPanel implements ActionListener{
	public static  Color c;
	protected JTextField View;
	protected JComboBox<String>liste;
	protected String[]content=new String[2];
	protected CouleurRGB rgbchooser;
	protected CouleurHEXA hexachooser;
	protected JPanel zone,main;
	protected Color[]recap=new Color[10];
	protected JButton bouton;
	protected JLabel mess=new JLabel("Choississez votre fa�on de choisir les couleurs");

	public CouleurChooser() {
		super();
		zone=new JPanel();
		main=new JPanel();
		bouton=new JButton("Terminer");
		main.setLayout(new BorderLayout());
		setLayout(new BorderLayout());
		View=new JTextField("\t\t\t");
		content[0]="CODE RGB | Palette";
		content[1]="CODE HEXA";
		liste=new JComboBox<>(content);
		zone.add(mess);
		main.add(View,BorderLayout.NORTH);
		main.add(liste,BorderLayout.CENTER);
		main.add(bouton, BorderLayout.EAST);
		//liste.addActionListener(this);
		liste.addActionListener(this);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource().equals(liste)){
			if(liste.getSelectedIndex()==0){ //RGB
				setVisible(false);
				add(rgbchooser);
				repaint();
				setVisible(true);
			}else if(liste.getSelectedIndex()==1){ //HEXA
				setVisible(false);
				add(hexachooser);
				repaint();
				setVisible(true);
			}
		}
	}
}
