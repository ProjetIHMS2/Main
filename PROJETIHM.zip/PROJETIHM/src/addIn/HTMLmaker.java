package addIn;


import java.awt.Color;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

import Menu_interfacePrincipales.PreVisualisation;

public class HTMLmaker {
	
		int cpt=1;
		int test=10; //TODO //remplacer par nb_couleur de ENTETE
		String ligne;
		FileReader flux;
		BufferedReader fichier;
		File tmp=new File("src/addIn/resume.html");
		PrintWriter w;
		final String debut_ligne="<tr>";
		final String fin_ligne="</tr>";
		int tmp_R=60,tmp_B=150,tmp_G=255;
		String nouvelleCouleur="<td class='rec' style='background-color: rgb("+tmp_R+","+tmp_G+","+tmp_B+")'></td>";
		
		
		
		
		
	public HTMLmaker(int nb) {

		try{
			w=new PrintWriter("src/addIn/resume.test.html");
			flux=new FileReader(tmp); 
			fichier=new BufferedReader(flux);
			while ((ligne=fichier.readLine())!=null){
				System.out.println("Avant"+cpt++ + "\t"+ligne);
				w.println(ligne);
				if(ligne.matches(".*<tbody>.*")){
					System.err.print("find");
					for ( @SuppressWarnings("unused") Color iterable_element : PreVisualisation.listeToHTML) {
						if(cpt % 2 == 0){
							System.err.print("colonne 1");
							tmp_R=iterable_element.getRed();
							tmp_G=iterable_element.getGreen();
							tmp_B=iterable_element.getBlue();
							//TODO refaire le string 
							//TODO rechercher pk �a update pas a chaque instance
							System.err.println(tmp_R+","+tmp_G+","+tmp_B);
							w.println(debut_ligne+nouvelleCouleur);
						}else{
							System.err.print("colonne 2");
							w.println(nouvelleCouleur+fin_ligne);
						}
						cpt++;
					}
				}
			}
			flux.close();
			fichier.close(); 
			w.close();
		}
		catch (IOException e){
			System.err.println("Erreur ==> "+e.toString());
		}
	}
	public static void main(String[] args) {
		int nb;
		System.err.println("tape qqchose");
		nb=new Scanner(System.in).nextInt();
		new HTMLmaker(nb);
	}
}