package addIn;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class MotJava {

	public static void main(String[] args) {
		String ligne;
		FileReader flux;
		BufferedReader fichier;
		File tmp=new File("src/addIn/resume.html");
		PrintWriter w;
		


		try{
			w=new PrintWriter("src/addIn/resume.test.txt");
			flux=new FileReader(tmp); 
			fichier=new BufferedReader(flux);
			while ((ligne=fichier.readLine())!=null){
				System.out.println("\t"+ligne);
				w.println();
			}
			flux.close();
			fichier.close(); 
			w.close();
		}
		catch (Exception e){
			System.err.println("Erreur ==> "+e.toString());
		}
	}
}


