package addIn;

import java.awt.Color;
import java.awt.Desktop;
import java.awt.FlowLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class ENTETEPAGE extends JPanel implements ActionListener{
	
	
	private static final long serialVersionUID = 1L;
	
	
	protected JButton helpIcon,generer;
	protected File helpPage=new File("src/addIn/help.html");
	protected File HTML=new File("src/addIn/resume.test.html");
	protected JLabel Title=new JLabel();
	protected Desktop desktop = Desktop.getDesktop();
	public ENTETEPAGE() {
		setLayout(new FlowLayout());
		helpIcon=new JButton("HELP PAGE");
		generer=new JButton("Generer HTML");
		generer.setBackground(Color.black);
		generer.setForeground(Color.orange);
		helpIcon.setBackground(Color.black);
		helpIcon.setForeground(Color.orange);
		Title.setText("PROJET IHM S2");
		helpIcon.setMargin(new Insets(20, 20, 20, 20));
		generer.setMargin(new Insets(20, 20, 20, 20));

		add(generer);
		add(Title);
		add(helpIcon);
		setVisible(true);
		//action listener
		helpIcon.addActionListener(this);
		generer.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource().equals(generer)){
			try {
				new HTMLmaker(10);
				desktop.open(HTML);
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}else if(e.getSource().equals(helpIcon)){
			try {
				desktop.open(helpPage);
			} catch (IOException e1) {
			
				e1.printStackTrace();
			}
		}
		
	}
}
