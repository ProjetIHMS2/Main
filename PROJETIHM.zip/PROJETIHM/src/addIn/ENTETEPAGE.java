package addIn;

import java.awt.BorderLayout;
import java.awt.Desktop;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import Menu_interfacePrincipales.CouleurChooser;
import Menu_interfacePrincipales.Main;
import Menu_interfacePrincipales.MainActivity;
import Menu_interfacePrincipales.PreVisualisation;
public class ENTETEPAGE extends JPanel implements ActionListener{
	
	
	private static final long serialVersionUID = 1L;
	
	
	protected JButton helpIcon,generer;
	protected File helpPage=new File("src/addIn/help.html");
	protected File HTML=new File("src/addIn/resume.test.html");
	protected JTextField title=new JTextField();
	protected Desktop desktop = Desktop.getDesktop();
	public ENTETEPAGE() {
		setLayout(new BorderLayout());
		helpIcon=new JButton("HELP PAGE");
		generer=new JButton("Generer HTML");
		
		title.setText("\t\t test");
		add(title,BorderLayout.CENTER);
		add(generer,BorderLayout.WEST);
		add(helpIcon,BorderLayout.EAST);
		setVisible(true);
		//action listener
		helpIcon.addActionListener(this);
		generer.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource().equals(generer)){
			try {
				new HTMLmaker(10);
				desktop.open(HTML);
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}else if(e.getSource().equals(helpIcon)){
			try {
				desktop.open(helpPage);
			} catch (IOException e1) {
			
				e1.printStackTrace();
			}
		}
		
	}
}
